const { useState, useEffect } = React;

// --- 1. Helper Functions ---
const formatNumber = (num) => num != null ? new Intl.NumberFormat().format(num) : 'N/A';

const formatDuration = (ms) => {
    if (ms == null || ms < 0) return 'N/A'; // Handle null or negative
    if (ms < 1000) return `${ms}ms`;
    const seconds = (ms / 1000);
    if (seconds < 60) return `${seconds.toFixed(1)}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.round(seconds % 60); // Use round for cleaner display
    const paddedSeconds = String(remainingSeconds).padStart(2, '0');
    return `${minutes}m ${paddedSeconds}s`;
};

const formatCost = (cost) => cost != null ? `$${cost.toFixed(6)}` : 'N/A'; // Increased precision

// Simple function to capitalize status strings nicely
const formatStatus = (statusStr) => {
    if (!statusStr) return 'N/A';
    return statusStr.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()); // Capitalize words
}

// --- 2. Basic Building Block Components ---
const CodeBlock = ({ content }) => {
    // Simple preformatted display for code/prompts
    if (!content) return React.createElement('div', { className: 'code-block', style: { color: '#9ca3af' } }, 'No content available.');

    return React.createElement('pre', { className: 'code-block' }, content);
};

const ToggleableCodeBlock = ({ content, buttonTextShow = 'Show', buttonTextHide = 'Hide', defaultExpanded = false }) => {
    const [isExpanded, setIsExpanded] = useState(defaultExpanded);
    if (!content) return null; // Don't render button if no content

    return React.createElement('div', { style: { marginTop: '5px' } },
        React.createElement('button', {
            className: 'toggle-button',
            onClick: () => setIsExpanded(!isExpanded)
        }, isExpanded ? buttonTextHide : buttonTextShow),
        isExpanded && React.createElement(CodeBlock, { content: content })
    );
};

const ValidationAttemptDisplay = ({ attempt, attemptIndex }) => {
    const statusClass = attempt.is_valid ? 'status status-success' : 'status status-failed_validation'; // Specific class
    const statusText = attempt.is_valid ? '✓ Valid' : '✗ Invalid';
    const attemptClass = `validation-attempt ${!attempt.is_valid ? 'failed' : ''}`;

    return React.createElement('div', { className: attemptClass },
        `Validation Attempt ${attemptIndex}: `, // Use index passed from map
        React.createElement('span', { className: statusClass }, statusText),
        !attempt.is_valid && attempt.errors && attempt.errors.length > 0 && React.createElement('div', { className: 'error-block', style: { marginTop: '4px' } },
            React.createElement('strong', null, 'Errors:'),
            React.createElement('ul', null,
                attempt.errors.map((err, i) => React.createElement('li', { key: i }, err))
            )
        )
    );
};


// --- 3. More Complex Components ---
const LLMCall = ({ call, validationAttempts = [] }) => {
    const llmCallAttemptNumber = call.model_params?.retry_attempt ?? 0;
    // Use a more descriptive status for the API call itself
    const apiStatus = call.status === 'success' ? 'api_success' : 'api_failed';
    const apiStatusText = call.status === 'success' ? '✓ API Success' : '✗ API Failed';

    return React.createElement('div', { className: 'llm-call' },
        React.createElement('div', { className: 'llm-call-header' },
            React.createElement('strong', null, `${formatStatus(call.call_type)} (LLM Call Attempt ${llmCallAttemptNumber})`),
            // Display API success/failure status clearly
            React.createElement('span', { className: `status status-${apiStatus}` }, apiStatusText)
        ),
        React.createElement('div', { className: 'llm-call-details' },
            `Provider: ${call.provider || 'N/A'} | Model: ${call.model || 'N/A'} | `,
            `Duration: ${formatDuration(call.duration_ms)} | Tokens: ${formatNumber(call.tokens_used)} | Cost: ${formatCost(call.cost_usd)} | `,
            `Finish: ${call.finish_reason || 'N/A'}`
        ),
        // Display API Error message ONLY if the API call actually failed
        call.status === 'failure' && call.error && React.createElement('div', { className: 'error-block' },
             React.createElement('strong', null, `API Error (${call.error_type || 'Unknown'}):`), ` ${call.error}`
        ),
        // Show prompt/response toggle buttons regardless of API success/failure (prompt exists even on failure)
        React.createElement(ToggleableCodeBlock, { content: call.prompt, buttonTextShow: 'Show Prompt', buttonTextHide: 'Hide Prompt' }),
        // Only show response button if response likely exists (API success)
        call.status === 'success' && call.response && React.createElement(ToggleableCodeBlock, { content: call.response, buttonTextShow: 'Show Response', buttonTextHide: 'Hide Response' }),

        // Only show Validation Results if the API call was successful AND there are validation attempts logged for it
        call.status === 'success' && validationAttempts.length > 0 && React.createElement('div', { style: { marginTop: '8px', borderTop: '1px dashed #ddd', paddingTop: '8px' } },
             React.createElement('strong', { style: { fontSize: '12px', color: '#374151', display: 'block', marginBottom: '4px' } }, `Validation Result${validationAttempts.length > 1 ? 's' : ''}:`),
             validationAttempts
                // Sort by timestamp just in case they are out of order
                .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp))
                .map((attempt, idx) =>
                     // The index 'idx' (starting from 0) correctly numbers the validation attempts *for this specific LLM call's output*
                     React.createElement(ValidationAttemptDisplay, {
                         key: attempt.attempt_id + '-' + idx, // Unique key for React
                         attempt: attempt,
                         attemptIndex: idx // Pass the 0-based index for display
                     })
             )
        )

    );
};

const Entity = ({ entity }) => {
    const [expanded, setExpanded] = useState(false);
    // Use a generic failed status for border if any failure type
    const headerStatusClass = entity.status.startsWith('failed') ? 'failed'
    : entity.status === 'partial_success' ? 'partial_success'
    : entity.status === 'ignored' ? 'ignored'
    : 'success';
    const displayStatus = formatStatus(entity.status);

    // Get all LLM calls and sort them by their retry attempt number
    const allLLMCalls = (entity.llm_requests || [])
        .sort((a, b) => (a.model_params?.retry_attempt ?? 0) - (b.model_params?.retry_attempt ?? 0)); // Sort by LLM attempt

    // Group validation attempts by their corresponding LLM attempt_id
    const validationAttemptsById = (entity.validation_attempts || []).reduce((acc, attempt) => {
        const id = attempt.attempt_id; // This ID links validation to LLM call
        if (!acc[id]) acc[id] = [];
        acc[id].push(attempt);
        return acc;
    }, {});

     // Use the direct count from stats.py
     const totalEntityRetries = entity.validation_retry_count || 0;

    // Create a unique, safe ID for linking
    const safeEntityId = `entity-${entity.entity_id.replace(/[^a-zA-Z0-9_-]/g, '_')}`;

    return React.createElement('div', { className: 'entity-item' },
        React.createElement('div', {
            className: `entity-header ${headerStatusClass}`,
            onClick: () => setExpanded(!expanded),
            id: safeEntityId // Use safe ID
        },
            React.createElement('span', { className: 'entity-name' },
                `${entity.entity_type === 'endpoint' ? '🔗' : '📄'} ${entity.entity_id}`,
                 // Show retry count badge in header if > 0 - Uses correct field
                 totalEntityRetries > 0 && React.createElement('span', { className: 'retry-indicator' }, `🔄 ${totalEntityRetries} ${totalEntityRetries === 1 ? 'Retry' : 'Retries'}`)
            ),
            // Use specific status class for the text badge
            React.createElement('span', { className: `status status-${entity.status}` }, displayStatus),
            React.createElement('span', { className: `collapse-icon ${expanded ? 'expanded' : ''}` }, '▶')
        ),
        React.createElement('div', { className: `collapsible-content ${expanded ? 'expanded' : ''}` },
             expanded && React.createElement('div', { className: 'entity-content' },
                React.createElement('div', { style: { marginBottom: '10px', color: '#4b5563' } },
                    React.createElement('strong', null, 'Duration: '), `${formatDuration(entity.duration_ms)} | `,
                    React.createElement('strong', null, 'Started: '), `${new Date(entity.start_time).toLocaleString()} | `,
                    React.createElement('strong', null, 'Ended: '), `${entity.end_time ? new Date(entity.end_time).toLocaleString() : 'N/A'}`
                ),
                 // Extra code info (existing logic seems fine)
                 entity.extra_code_requested && React.createElement('div', { style: { fontStyle: 'italic', fontSize: '12px', color: '#6b7280', marginBottom: '10px' } },
                      `Extra code requested ${entity.extra_code_count} time(s) for components: ${entity.extra_code_components.join(', ') || 'None specified'}.`
                 ),
                 // Display final entity error if processing failed
                 entity.status !== 'success' && entity.status !== 'ignored' && entity.error && React.createElement('div', { className: 'error-block', style:{ marginBottom: '15px'} },
                    React.createElement('strong', null, `Entity Error (${formatStatus(entity.error_type) || 'Unknown'}):`), ` ${entity.error}`
                 ),

                React.createElement('h4', null, 'LLM Calls & Validation History'),
                allLLMCalls.length > 0
                    ? allLLMCalls.map((call, idx) => {
                        // Get validation attempts specifically linked to this call's attempt_id
                        const attemptsForThisCall = validationAttemptsById[call.attempt_id] || [];
                        return React.createElement(LLMCall, {
                            key: call.attempt_id || idx, // Use attempt_id if available
                            call: call,
                            validationAttempts: attemptsForThisCall
                        });
                      })
                    : React.createElement('p', { style: { color: '#6b7280' } }, 'No LLM calls recorded for this entity.')
            ) // End entity-content
        ) // End collapsible-content
    ); // End entity-item
};


// --- 4. Main Application Component ---
const StatsDashboard = () => {
    // Safely access nested data
    const stats = window.statsData || {};
    const llmStats = stats.llm_stats || {};
    const validationStats = stats.validation_stats || {};
    const serializerStats = stats.serializers || { entities: [], status_counts: {}, total: 0 };
    const endpointStats = stats.endpoints || { entities: [], status_counts: {}, total: 0 };
    const callTypeStats = llmStats.by_call_type || {};

    const summaryCards = [
        { title: "Total Duration", value: formatDuration(stats.duration_ms), icon: "⏱️" },
        { title: "Total Cost (USD)", value: formatCost(llmStats.total_cost_usd), icon: "💰" },
        { title: "Total Tokens", value: formatNumber(llmStats.total_tokens), icon: "📝" },
        // Using safe access for status counts
        { title: "Endpoints Success", value: `${endpointStats.status_counts?.success || 0}/${endpointStats.total || 0}`, icon: "🔗" },
        { title: "Serializers Success", value: `${serializerStats.status_counts?.success || 0}/${serializerStats.total || 0}`, icon: "📄" },
        // Uses correct global retry count field
        { title: "Validation Retries", value: formatNumber(validationStats.total_validation_retries), icon: "🔄" },
    ];

     // Filter failed entities (any status starting with 'failed')
     const failedEntities = [
        ...(serializerStats.entities || []),
        ...(endpointStats.entities || [])
    ].filter(e => e.status && e.status.startsWith('failed'));

    // Filter entities with validation retries (using the direct count)
    const highRetryEntities = [
         ...(serializerStats.entities || []),
         ...(endpointStats.entities || [])
    ].filter(e => (e.validation_retry_count || 0) > 0) // Filter entities with > 0 retries
     .sort((a, b) => (b.validation_retry_count || 0) - (a.validation_retry_count || 0)); // Sort descending by retry count


    return React.createElement('div', { className: 'container' },
        React.createElement('div', { className: 'header' },
            React.createElement('h1', { className: 'title' }, 'OpenAPI Generation Stats'),
            React.createElement('p', { className: 'subtitle' }, `Repository: ${stats.repo_name || 'N/A'} | Run ID: ${stats.run_id || 'N/A'}`)
        ),
        React.createElement('div', { className: 'grid' },
            summaryCards.map((card, idx) =>
                React.createElement('div', { key: idx, className: 'stat-card' },
                    React.createElement('h3', null, card.icon, ' ', card.title),
                    React.createElement('p', null, card.value)
                )
            )
        ),
        // LLM Stats Table
        React.createElement('div', { className: 'card' },
             React.createElement('h2', null, 'LLM Call Statistics'),
             React.createElement('table', { className: 'table' },
                React.createElement('thead', null,
                     React.createElement('tr', null,
                        React.createElement('th', null, 'Call Type'),
                        React.createElement('th', null, 'Calls'),
                        React.createElement('th', null, 'Tokens'),
                        React.createElement('th', null, 'Cost (USD)'),
                        React.createElement('th', null, 'Avg Duration')
                     )
                ),
                React.createElement('tbody', null,
                     // Iterate over the keys provided in the data
                     Object.keys(callTypeStats).map((typeKey) => {
                         const data = callTypeStats[typeKey];
                         return React.createElement('tr', { key: typeKey },
                             React.createElement('td', null, formatStatus(typeKey)), // Format the type key
                             React.createElement('td', null, formatNumber(data.calls)),
                             React.createElement('td', null, formatNumber(data.tokens)),
                             React.createElement('td', null, formatCost(data.cost_usd)),
                             React.createElement('td', null, formatDuration(data.avg_duration_ms))
                         );
                     })
                 )
             )
        ),
        // Entities sections
         React.createElement('div', { className: 'card' },
            React.createElement('h2', null, `Endpoints (${endpointStats.total || 0})`),
            React.createElement('div', { className: 'entity-list' },
                 (endpointStats.entities && endpointStats.entities.length > 0)
                 ? endpointStats.entities.map((entity, idx) => React.createElement(Entity, { key: entity.entity_id || idx, entity: entity }))
                 : React.createElement('p', { style: { color: '#6b7280' } }, 'No endpoints processed.')
            )
        ),
         React.createElement('div', { className: 'card' },
            React.createElement('h2', null, `Serializers (${serializerStats.total || 0})`),
             React.createElement('div', { className: 'entity-list' },
                  (serializerStats.entities && serializerStats.entities.length > 0)
                  ? serializerStats.entities.map((entity, idx) => React.createElement(Entity, { key: entity.entity_id || idx, entity: entity }))
                  : React.createElement('p', { style: { color: '#6b7280' } }, 'No serializers processed.')
            )
        ),

        // Failure/Retry Analysis Section
         React.createElement('div', { className: 'card' },
             React.createElement('h2', null, 'Failure & Retry Analysis'),
             React.createElement('div', { className: 'grid', style: { gridTemplateColumns: '1fr 1fr', gap: '25px' } }, // Side-by-side tables

                 // Failed Entities Table
                 React.createElement('div', null,
                     React.createElement('h3', { style: { marginTop: '0'} }, `Failed Entities (${failedEntities.length})`),
                     failedEntities.length > 0 ? React.createElement('table', { className: 'table' },
                         React.createElement('thead', null, /* ... thead ... */
                              React.createElement('tr', null,
                                 React.createElement('th', null, 'Entity ID'), React.createElement('th', null, 'Type'),
                                 React.createElement('th', null, 'Final Status'), React.createElement('th', null, 'Error Type')
                             )
                         ),
                         React.createElement('tbody', null, /* ... tbody ... */
                              failedEntities.map((entity, idx) => {
                                  const safeId = `entity-${entity.entity_id.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
                                  return React.createElement('tr', { key: `fail-${idx}` },
                                       React.createElement('td', null, React.createElement('a', { href: `#${safeId}` }, entity.entity_id)),
                                       React.createElement('td', null, formatStatus(entity.entity_type)),
                                       React.createElement('td', null, React.createElement('span', { className: `status status-${entity.status}` }, formatStatus(entity.status))),
                                       React.createElement('td', { title: entity.error }, formatStatus(entity.error_type) || 'Unknown') // Show error type, hover for details
                                   )
                               })
                          )
                     ) : React.createElement('p', { style: { color: '#6b7280' } }, 'No entities failed processing.')
                 ), // End Failed Entities Div

                 // Entities with Retries Table
                 React.createElement('div', null,
                      React.createElement('h3', { style: { marginTop: '0'} }, `Entities with Validation Retries (${highRetryEntities.length})`),
                      highRetryEntities.length > 0 ? React.createElement('table', { className: 'table' },
                          React.createElement('thead', null, /* ... thead ... */
                              React.createElement('tr', null,
                                 React.createElement('th', null, 'Entity ID'), React.createElement('th', null, 'Type'),
                                 React.createElement('th', null, 'Total Retries'), React.createElement('th', null, 'Final Status')
                             )
                          ),
                          React.createElement('tbody', null, /* ... tbody ... */
                               highRetryEntities.map((entity, idx) => {
                                   const safeId = `entity-${entity.entity_id.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
                                   const totalRetries = entity.validation_retry_count || 0;
                                   return React.createElement('tr', { key: `retry-${idx}` },
                                       React.createElement('td', null, React.createElement('a', { href: `#${safeId}` }, entity.entity_id)),
                                       React.createElement('td', null, formatStatus(entity.entity_type)),
                                       React.createElement('td', { style: { textAlign: 'center' } }, totalRetries), // Center align retry count
                                       React.createElement('td', null, React.createElement('span', { className: `status status-${entity.status}` }, formatStatus(entity.status)))
                                   );
                               })
                          )
                      ) : React.createElement('p', { style: { color: '#6b7280' } }, 'No entities triggered validation retries.')
                 ) // End Retries Div
             ) // End Grid for Analysis Tables
         ) // End Failure/Retry Analysis Card
    ); // End Container
}; // End StatsDashboard

// --- 5. Mount the Application ---
const rootElement = document.getElementById('root');
if (rootElement) {
    const reactRoot = ReactDOM.createRoot(rootElement);
    reactRoot.render(React.createElement(StatsDashboard));
} else {
    console.error("Root element (#root) not found for React mounting.");
}